// Model class
class TodoModel {
  String uid;
  String title;
  bool isCompleted;

  TodoModel(
      {required this.uid, required this.isCompleted, required this.title});
}
