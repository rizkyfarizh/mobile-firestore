package com.example.firebase_display

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
